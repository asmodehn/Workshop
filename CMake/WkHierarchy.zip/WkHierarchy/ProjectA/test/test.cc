#include "header.hh"

int main ( int argc, char* argv[] )
{
	return displayXX("test");
}
