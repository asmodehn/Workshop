#include "header.hh"

//including and hiding dependency header
#include "header.h"

int displayXX(std::string txt)
{
	return display(txt.c_str());
}
