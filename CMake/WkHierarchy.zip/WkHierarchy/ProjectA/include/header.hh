#ifndef HEADER_HH
#define HEADER_HH

#include <string>

int displayXX(std::string txt);

#endif
