#include "header.h"

#include <stdio.h>

int display(const char* txt)
{
	printf("%s\n",txt);
	return 0;
}
